$(function() {

$( "#menuToggle" ).click(function() {
	$('body').toggleClass('open_nav');
});


var $carousel = $('.main-carousel').flickity({
	cellAlign: 'center',
	contain: true,
	freeScroll: false,
	wrapAround: true,
	autoPlay: 3000,
	lazyLoad: 2,
	selectedAttraction: 0.01,
	pauseAutoPlayOnHover: false,
  	on: {
    	ready: function() {
    },
    change: function( index ) {
    }
  }
});


var $carousel = $('.main-carousel-2').flickity({
	cellAlign: 'center',
	contain: true,
	freeScroll: false,
	wrapAround: true,
	pageDots: false,
	autoPlay: 3000,
	lazyLoad: 2,
	selectedAttraction: 0.01,
	pauseAutoPlayOnHover: false,
  	on: {
    	ready: function() {
    },
    change: function( index ) {
    }
  }
});



	showdiv();
	$(window).scroll(function() {
		showdiv();
	});

	function showdiv(){
		var col = $('.banner-arrow-child');
		var x = 1;
		$(col).not('.visible').each(function(i) {
			if ($(this).is(':visible')){
				var a = $(this).offset().top;
				var b = $(window).scrollTop() + $(window).height();
				if (a < b && !$(this).hasClass('vissible')) {
					    var delay = x * 100;
					    var delay = delay + 'ms';
						$(this).addClass('vissible');
						$(this).css("transition-delay", delay);
						x++;
				}
				
			}
		});
	}



});